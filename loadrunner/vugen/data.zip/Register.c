Register()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("demowebshop.tricentis.com", 
		"URL=http://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-divider.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/bullet-right.gif", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-active.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/loading.gif", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/star-x-inactive.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/arrows.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/bullets.png", "Referer=https://demowebshop.tricentis.com/Plugins/Widgets.NivoSlider/Content/nivoslider/themes/default/default.css", ENDITEM, 
		"Url=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-triangle.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		LAST);

	lr_think_time(6);

	lr_start_transaction("Test");

	web_link("Register", 
		"Text=Register", 
		"Snapshot=t18.inf", 
		LAST);

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=tpU2nrUlUXsuLrdqQV-ORmSPnYoK7C0rbTeXufPCfAtF-fg06riBryXwIY1Jt1DAVEv-Cogzsmrz3mofJPEd-voZ-CQfFEYbjjX552mP9mU1", ENDITEM, 
		"Name=Gender", "Value=M", ENDITEM, 
		"Name=FirstName", "Value=Aguero", ENDITEM, 
		"Name=LastName", "Value=Agnes", ENDITEM, 
		"Name=Email", "Value=test@3732.com", ENDITEM, 
		"Name=Password", "Value=pass123", ENDITEM, 
		"Name=ConfirmPassword", "Value=pass123", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_link("Log out", 
		"Text=Log out", 
		"Snapshot=t20.inf", 
		LAST);

	return 0;
}
