addtocart()
{

	web_add_cookie("__utma=78382081.212827302.1765353909.1765353909.1765353909.1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmc=78382081; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmz=78382081.1765353909.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmt=1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.1.10.1765353909; DOMAIN=demowebshop.tricentis.com");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	lr_think_time(11);

	web_url("ajax_loader_large.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ajax_loader_large.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t25.inf", 
		LAST);

	web_custom_request("1", 
		"URL=https://demowebshop.tricentis.com/addproducttocart/catalog/31/1/1", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/notebooks", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=", 
		EXTRARES, 
		"Url=/Themes/DefaultClean/Content/images/ico-close-notification-bar.png", "Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", ENDITEM, 
		"Url=/content/images/thumbs/0000224_141-inch-laptop_47.png", "Referer=https://demowebshop.tricentis.com/notebooks", ENDITEM, 
		LAST);

	web_add_cookie("__utmb=78382081.2.10.1765353909; DOMAIN=demowebshop.tricentis.com");

	web_url("cart", 
		"URL=https://demowebshop.tricentis.com/cart", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/notebooks", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-icons_888888_256x240.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_highlight-soft_75_cccccc_1x100.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_75_dadada_1x400.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_75_e6e6e6_1x400.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-icons_222222_256x240.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-icons_454545_256x240.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		"Url=/Content/jquery-ui-themes/smoothness/images/ui-bg_glass_65_ffffff_1x400.png", "Referer=https://demowebshop.tricentis.com/Content/jquery-ui-themes/smoothness/jquery-ui-1.10.3.custom.min.css", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=removefromcart", "Value=6124235", ENDITEM, 
		"Name=itemquantity6124235", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=0", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	return 0;
}
