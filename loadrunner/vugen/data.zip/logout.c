logout()
{

	web_add_cookie("__utmb=78382081.4.10.1765354182; DOMAIN=demowebshop.tricentis.com");

	web_add_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("logout", 
		"URL=https://demowebshop.tricentis.com/logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/notebooks", 
		"Snapshot=t71.inf", 
		"Mode=HTTP", 
		LAST);

	return 0;
}