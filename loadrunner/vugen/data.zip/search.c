search()
{

	web_add_cookie("__utmb=78382081.3.10.1765354182; DOMAIN=demowebshop.tricentis.com");

	web_add_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_concurrent_start(NULL);

	web_url("top-menu-list-image.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t66.inf", 
		LAST);

	web_add_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("top-menu-background.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-background.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t67.inf", 
		LAST);

	web_add_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("top-menu-list-image-hover.png", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/top-menu-list-image-hover.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t68.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	lr_think_time(5);

	web_url("notebooks", 
		"URL=https://demowebshop.tricentis.com/notebooks", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t69.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("ico-arrow-r.gif", 
		"URL=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/images/ico-arrow-r.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://demowebshop.tricentis.com/Themes/DefaultClean/Content/styles.css", 
		"Snapshot=t70.inf", 
		LAST);

	return 0;
}
